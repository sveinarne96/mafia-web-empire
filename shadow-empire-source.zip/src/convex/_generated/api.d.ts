/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as actions500 from "../actions500.js";
import type * as admin from "../admin.js";
import type * as adminWipe from "../adminWipe.js";
import type * as advancedFeatures from "../advancedFeatures.js";
import type * as allFeatures from "../allFeatures.js";
import type * as armoury from "../armoury.js";
import type * as arsenal from "../arsenal.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as authCustom from "../authCustom.js";
import type * as businessSystem from "../businessSystem.js";
import type * as casinoSystem from "../casinoSystem.js";
import type * as communitySystem from "../communitySystem.js";
import type * as crimeExtras from "../crimeExtras.js";
import type * as crons from "../crons.js";
import type * as dailyReward from "../dailyReward.js";
import type * as demolitionDerby from "../demolitionDerby.js";
import type * as drugSystem from "../drugSystem.js";
import type * as easterEggItems from "../easterEggItems.js";
import type * as empireFeatures from "../empireFeatures.js";
import type * as empireSystem from "../empireSystem.js";
import type * as eventGifts from "../eventGifts.js";
import type * as expansion from "../expansion.js";
import type * as game from "../game.js";
import type * as gameControl from "../gameControl.js";
import type * as gameEnhanced from "../gameEnhanced.js";
import type * as gameExtended from "../gameExtended.js";
import type * as gameFeatures from "../gameFeatures.js";
import type * as gameUpdates from "../gameUpdates.js";
import type * as hitSystem from "../hitSystem.js";
import type * as hospitalSystem from "../hospitalSystem.js";
import type * as http from "../http.js";
import type * as intelligence from "../intelligence.js";
import type * as lastManStanding from "../lastManStanding.js";
import type * as megaPack from "../megaPack.js";
import type * as missionSystem from "../missionSystem.js";
import type * as missionsBoard from "../missionsBoard.js";
import type * as murderNetwork from "../murderNetwork.js";
import type * as murderSystem from "../murderSystem.js";
import type * as ocTeams from "../ocTeams.js";
import type * as profileSystem from "../profileSystem.js";
import type * as quicktrade from "../quicktrade.js";
import type * as rackets from "../rackets.js";
import type * as referralSystem from "../referralSystem.js";
import type * as resourceSystem from "../resourceSystem.js";
import type * as retentionSystem from "../retentionSystem.js";
import type * as seasonSystem from "../seasonSystem.js";
import type * as seedMissions from "../seedMissions.js";
import type * as serverOps from "../serverOps.js";
import type * as statistics from "../statistics.js";
import type * as storeSystem from "../storeSystem.js";
import type * as underground from "../underground.js";
import type * as users from "../users.js";
import type * as witnessMarket from "../witnessMarket.js";
import type * as worldSystem from "../worldSystem.js";
import type * as xpVolume from "../xpVolume.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  actions500: typeof actions500;
  admin: typeof admin;
  adminWipe: typeof adminWipe;
  advancedFeatures: typeof advancedFeatures;
  allFeatures: typeof allFeatures;
  armoury: typeof armoury;
  arsenal: typeof arsenal;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  authCustom: typeof authCustom;
  businessSystem: typeof businessSystem;
  casinoSystem: typeof casinoSystem;
  communitySystem: typeof communitySystem;
  crimeExtras: typeof crimeExtras;
  crons: typeof crons;
  dailyReward: typeof dailyReward;
  demolitionDerby: typeof demolitionDerby;
  drugSystem: typeof drugSystem;
  easterEggItems: typeof easterEggItems;
  empireFeatures: typeof empireFeatures;
  empireSystem: typeof empireSystem;
  eventGifts: typeof eventGifts;
  expansion: typeof expansion;
  game: typeof game;
  gameControl: typeof gameControl;
  gameEnhanced: typeof gameEnhanced;
  gameExtended: typeof gameExtended;
  gameFeatures: typeof gameFeatures;
  gameUpdates: typeof gameUpdates;
  hitSystem: typeof hitSystem;
  hospitalSystem: typeof hospitalSystem;
  http: typeof http;
  intelligence: typeof intelligence;
  lastManStanding: typeof lastManStanding;
  megaPack: typeof megaPack;
  missionSystem: typeof missionSystem;
  missionsBoard: typeof missionsBoard;
  murderNetwork: typeof murderNetwork;
  murderSystem: typeof murderSystem;
  ocTeams: typeof ocTeams;
  profileSystem: typeof profileSystem;
  quicktrade: typeof quicktrade;
  rackets: typeof rackets;
  referralSystem: typeof referralSystem;
  resourceSystem: typeof resourceSystem;
  retentionSystem: typeof retentionSystem;
  seasonSystem: typeof seasonSystem;
  seedMissions: typeof seedMissions;
  serverOps: typeof serverOps;
  statistics: typeof statistics;
  storeSystem: typeof storeSystem;
  underground: typeof underground;
  users: typeof users;
  witnessMarket: typeof witnessMarket;
  worldSystem: typeof worldSystem;
  xpVolume: typeof xpVolume;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
